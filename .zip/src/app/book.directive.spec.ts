import { BookDirective } from './book.directive';

describe('BookDirective', () => {
  it('should create an instance', () => {
    const directive = new BookDirective();
    expect(directive).toBeTruthy();
  });
});
